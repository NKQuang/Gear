@extends('admin.layout')

@section('content')
    <h1>Tạo tin tức mới</h1>

    <form action="{{ route('news.store') }}" method="POST" enctype="multipart/form-data">
        @csrf
        <div class="form-group">
            <label for="title">Tiêu đề</label>
            <input type="text" name="title" class="form-control" required>
        </div>

        <div class="form-group">
            <label for="content">Nội dung</label>
            <textarea name="content" class="form-control" rows="5" required></textarea>
        </div>

        <div class="form-group">
            <label for="image">Hình ảnh</label>
            <input type="file" name="image" class="form-control">
        </div>

        <div class="form-group">
            <label for="is_published">Xuất bản</label>
            <input type="checkbox" name="is_published">
        </div>

        <button type="submit" class="btn btn-primary">Lưu</button>
    </form>
@endsection
