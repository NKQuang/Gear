<?php $__env->startSection('content'); ?>
    <h1>Danh sách Loại Sản phẩm</h1>

    <a href="<?php echo e(route('product-types.create')); ?>" class="btn btn-primary">Tạo Loại Sản phẩm mới</a>

    <?php if(session('success')): ?>
        <div class="alert alert-success"><?php echo e(session('success')); ?></div>
    <?php endif; ?>

    <table class="table">
        <thead>
            <tr>
                <th>ID</th>
                <th>Tên loại sản phẩm (Tiếng Việt)</th>
                <th>Tên loại sản phẩm (English)</th>
                <th>Hành động</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $productTypes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $productType): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($productType->id); ?></td>
                    <!-- Hiển thị tên loại sản phẩm theo tiếng Việt -->
                    <td><?php echo e($productType->translations->where('locale', 'vi')->first()->name ?? 'Không có tên'); ?></td>
                    <!-- Hiển thị tên loại sản phẩm theo tiếng Anh -->
                    <td><?php echo e($productType->translations->where('locale', 'en')->first()->name ?? 'No name'); ?></td>
                    <td>
                        
                        <a href="<?php echo e(route('product-types.edit', $productType->id)); ?>" class="btn btn-warning">Sửa</a>
                        <form action="<?php echo e(route('product-types.destroy', $productType->id)); ?>" method="POST" style="display:inline;">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>
                            <button type="submit" class="btn btn-danger">Xóa</button>
                        </form>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampppp\htdocs\GEARS\resources\views/admin/product-types/index.blade.php ENDPATH**/ ?>