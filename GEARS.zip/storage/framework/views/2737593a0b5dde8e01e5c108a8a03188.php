<?php $__env->startSection('content'); ?>
    <h1>Chi tiết Đơn hàng #<?php echo e($order->id); ?></h1>

    <table class="table">
        <thead>
            <tr>
                <th>SKU</th>
                <th>Tên sản phẩm</th>
                <th>Số lượng</th>
                <th>Giá</th>
                <th>Tổng</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $orderDetails; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $detail): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($detail->product->sku); ?></td>
                    <td><?php echo e($detail->product_name); ?></td>
                    <td><?php echo e($detail->quantity); ?></td>
                    <td><?php echo e(number_format($detail->price, 2)); ?> USD</td>
                    <td><?php echo e(number_format($detail->subtotal, 2)); ?> USD</td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampppp\htdocs\GEARS\resources\views/admin/orders/show.blade.php ENDPATH**/ ?>