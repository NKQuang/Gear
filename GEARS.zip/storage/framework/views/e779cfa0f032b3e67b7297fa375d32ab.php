<?php $__env->startSection('content'); ?>
<form action="<?php echo e(route('update.exchange.rate')); ?>" method="POST">
    <?php echo csrf_field(); ?>
    <div class="form-group">
        <label for="usd_to_vnd">USD to VND:</label>
        <input type="text" id="usd_to_vnd" name="usd_to_vnd" value="<?php echo e($usd_to_vnd); ?>" class="form-control">
    </div>
    <button type="submit" class="btn btn-primary">Update</button>
</form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampppp\htdocs\GEARS\resources\views/admin/config/index.blade.php ENDPATH**/ ?>