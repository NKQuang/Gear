<?php $__env->startSection('content'); ?>
    <h1>Chỉnh sửa tin tức</h1>

    <!-- Hiển thị thông báo lỗi nếu có -->
    <?php if($errors->any()): ?>
        <div class="alert alert-danger">
            <ul>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    <?php endif; ?>

    <!-- Form chỉnh sửa tin tức -->
    <form action="<?php echo e(route('news.update', $news->id)); ?>" method="POST" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?> <!-- Sử dụng phương thức PUT cho cập nhật -->

        <!-- Tiêu đề -->
        <div class="form-group">
            <label for="title">Tiêu đề</label>
            <input type="text" name="title" class="form-control" value="<?php echo e(old('title', $news->title)); ?>" required>
        </div>

        <!-- Nội dung -->
        <div class="form-group">
            <label for="content">Nội dung</label>
            <textarea name="content" class="form-control" rows="5" required><?php echo e(old('content', $news->content)); ?></textarea>
        </div>

        <!-- Hình ảnh -->
        <div class="form-group">
            <label for="image">Hình ảnh</label>
            <?php if($news->image): ?>
                <div>
                    <img src="<?php echo e(Storage::url($news->image)); ?>" alt="<?php echo e($news->title); ?>" width="100">
                </div>
            <?php endif; ?>
            <input type="file" name="image" class="form-control">
        </div>

        <!-- Trạng thái xuất bản -->
        <div class="form-group">
            <label for="is_published">Xuất bản</label>
            <input type="checkbox" name="is_published" <?php echo e($news->is_published ? 'checked' : ''); ?>>
        </div>

        <!-- Nút lưu -->
        <button type="submit" class="btn btn-primary">Cập nhật</button>
    </form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampppp\htdocs\GEARS\resources\views/admin/news/edit.blade.php ENDPATH**/ ?>