<?php $__env->startSection('content'); ?>
    <h1>Danh sách Sản phẩm</h1>
    <a href="<?php echo e(route('products.create')); ?>" class="btn btn-primary">Thêm Sản phẩm</a>

    <table class="table">
        <thead>
            <tr>
                <th>Tên</th>
                <th>Mô tả</th>
                <th>Giá</th>
                <th>Loại</th>
                <th>Hành động</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php
                    $translation = $product->translations->where('locale', app()->getLocale())->first();
                ?>
                <tr>
                    <td><?php echo e($translation ? $translation->name : $product->name); ?></td>
                    <td><?php echo e($translation ? $translation->description : $product->description); ?></td>
                    <td><?php echo e(number_format($product->price, 2, '.', ',')); ?> USD</td> <!-- Format giá theo USD -->
                    <td><?php echo e($product->type->translations->where('locale', app()->getLocale())->first()->name ?? 'Không có tên'); ?></td>

                    <td>
                        <a href="<?php echo e(route('products.edit', $product->id)); ?>" class="btn btn-warning">Sửa</a>
                        <form action="<?php echo e(route('products.destroy', $product->id)); ?>" method="POST" style="display:inline;">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>
                            <button type="submit" class="btn btn-danger" onclick="return confirm('Bạn có chắc chắn muốn xóa?');">Xóa</button>
                        </form>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampppp\htdocs\GEARS\resources\views/admin/products/index.blade.php ENDPATH**/ ?>