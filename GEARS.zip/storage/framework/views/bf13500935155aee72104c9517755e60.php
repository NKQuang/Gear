<?php $__env->startSection('content'); ?>
    <!-- Product section-->
    <section class="py-5">
        <div class="container px-4 px-lg-5 my-5">
            <div class="row gx-4 gx-lg-5 align-items-center">
                <!-- Cột hình ảnh sản phẩm -->
<div class="col-md-6">
    <?php if($product->images->isNotEmpty()): ?>
        <!-- Carousel -->
        <div id="productCarousel" class="carousel slide">
            <div class="carousel-inner">
                <?php $__currentLoopData = $product->images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="carousel-item <?php echo e($index === 0 ? 'active' : ''); ?>">
                        <img class="d-block w-100 carousel-image" src="<?php echo e(asset('storage/' . $image->url)); ?>"
                            alt="<?php echo e($product->translations->where('locale', $locale)->first()->name); ?>" />
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
            <a class="carousel-control-prev" href="#productCarousel" role="button" data-bs-slide="prev">
                <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                <span class="visually-hidden">Previous</span>
            </a>
            <a class="carousel-control-next" href="#productCarousel" role="button" data-bs-slide="next">
                <span class="carousel-control-next-icon" aria-hidden="true"></span>
                <span class="visually-hidden">Next</span>
            </a>
        </div>
    <?php else: ?>
        <img class="card-img-top mb-5 mb-md-0" src="/img/about-1.png" alt="Default Image" />
    <?php endif; ?>
</div>
                <!-- Cột thông tin sản phẩm -->
                <div class="col-md-6">
                    <div class="small mb-1">SKU: <?php echo e($product->sku); ?></div>
                    <h1 class="display-5 fw-bolder"><?php echo e($product->translations->where('locale', $locale)->first()->name); ?>

                    </h1>
                    <div class="fs-5 mb-5">
                        <!-- Nếu có giá gốc và giá mới, hiển thị giá gốc bị gạch bỏ -->
                        <?php if($product->price_old): ?>
                            <span class="text-decoration-line-through">$<?php echo e($product->price_old); ?></span>
                        <?php endif; ?>
                        <span>$<?php echo e($product->price); ?></span>
                    </div>
                    <p class="lead">
                        <?php echo e($product->translations->where('locale', $locale)->first()->description); ?>

                    </p>
                    <div class="d-flex">
                        <input class="form-control text-center me-3" id="inputQuantity" type="number" value="1"
                            style="max-width: 3rem" />
                        <button class="btn btn-outline-dark flex-shrink-0 add-to-cart" data-id="<?php echo e($product->id); ?>"
                            data-name="<?php echo e($product->translations->where('locale', $locale)->first()->name); ?>"
                            data-price="<?php echo e($product->price); ?>"
                            data-image="<?php echo e(asset('storage/' . $product->images->first()->url ?? 'default.png')); ?>">
                            <i class="bi-cart-fill me-1"></i>
                            Add to cart
                        </button>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- Related items section-->
    <section class="py-5 bg-light">
        <div class="container px-4 px-lg-5 mt-5">
            <h2 class="fw-bolder mb-4">Related products</h2>
            <div class="row gx-4 gx-lg-5 row-cols-2 row-cols-md-3 row-cols-xl-4 justify-content-center">

                <?php $__currentLoopData = $relatedproducts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $relatedProduct): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col mb-5">
                        <div class="card h-100">
                            <!-- Product image-->
                            <?php if($relatedProduct->images->isNotEmpty()): ?>
                                <img class="card-img-top"
                                    src="<?php echo e(asset('storage/' . $relatedProduct->images->first()->url)); ?>"
                                    alt="<?php echo e($relatedProduct->translations->where('locale', $locale)->first()->name); ?>" />
                            <?php else: ?>
                                <img class="card-img-top" src="https://dummyimage.com/450x300/dee2e6/6c757d.jpg"
                                    alt="Default Image" />
                            <?php endif; ?>

                            <!-- Product details-->
                            <div class="card-body p-4">
                                <div class="text-center">
                                    <!-- Product name-->
                                    <h5 class="fw-bolder">
                                        <?php echo e($relatedProduct->translations->where('locale', $locale)->first()->name); ?></h5>
                                    <!-- Product price-->
                                    <?php if($relatedProduct->price): ?>

                                        $<?php echo e($relatedProduct->price); ?>

                                    <?php else: ?>
                                    Contact for price
                                    <?php endif; ?>
                                </div>
                            </div>

                            <!-- Product actions-->
                            <div class="card-footer p-4 pt-0 border-top-0 bg-transparent">
                                <div class="text-center">
                                    <a class="btn btn-outline-dark mt-auto"
                                        href="<?php echo e(route('productdetail', $relatedProduct->id)); ?>">See details</a>
                                </div>
                            </div>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </section>
    <!-- Modal -->
    <div class="modal fade" id="cartModal" tabindex="-1" aria-labelledby="cartModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="cartModalLabel">Notification</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    Product has been added to cart!
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                    <a href="/cart" class="btn btn-primary">View cart</a>
                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
    <script>
        document.addEventListener("DOMContentLoaded", function() {
            // Khi nhấn nút "Add to cart"
            document.querySelectorAll('.add-to-cart').forEach(function(button) {
                button.addEventListener('click', function() {
                    let productId = this.getAttribute('data-id');
                    let productName = this.getAttribute('data-name');
                    let productPrice = this.getAttribute('data-price');
                    let productImage = this.getAttribute('data-image');

                    // Lấy số lượng từ input
                    let quantityInput = this.parentElement.querySelector('#inputQuantity');
                    let quantity = parseInt(quantityInput.value) ||
                    1; // Nếu số lượng không hợp lệ, mặc định là 1

                    // Lấy giỏ hàng từ localStorage hoặc tạo giỏ hàng mới nếu chưa có
                    let cart = JSON.parse(localStorage.getItem('cart')) || [];

                    // Kiểm tra sản phẩm đã có trong giỏ hàng chưa
                    let existingProduct = cart.find(product => product.id === productId);

                    if (existingProduct) {
                        // Nếu có rồi, tăng số lượng lên
                        existingProduct.quantity += quantity;
                    } else {
                        // Nếu chưa có, thêm mới vào giỏ hàng
                        cart.push({
                            id: productId,
                            name: productName,
                            price: productPrice,
                            image: productImage,
                            quantity: quantity
                        });
                    }

                    // Cập nhật giỏ hàng vào localStorage
                    localStorage.setItem('cart', JSON.stringify(cart));

                    // Hiển thị modal
                    let cartModal = new bootstrap.Modal(document.getElementById('cartModal'), {
                        keyboard: true
                    });
                    cartModal.show();
                });
            });
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampppp\htdocs\GEARS\resources\views/productdetail.blade.php ENDPATH**/ ?>