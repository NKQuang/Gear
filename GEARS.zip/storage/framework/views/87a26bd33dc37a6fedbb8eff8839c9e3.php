<?php $__env->startSection('content'); ?>
    <h1>Tạo tin tức mới</h1>

    <form action="<?php echo e(route('news.store')); ?>" method="POST" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        <div class="form-group">
            <label for="title">Tiêu đề</label>
            <input type="text" name="title" class="form-control" required>
        </div>

        <div class="form-group">
            <label for="content">Nội dung</label>
            <textarea name="content" class="form-control" rows="5" required></textarea>
        </div>

        <div class="form-group">
            <label for="image">Hình ảnh</label>
            <input type="file" name="image" class="form-control">
        </div>

        <div class="form-group">
            <label for="is_published">Xuất bản</label>
            <input type="checkbox" name="is_published">
        </div>

        <button type="submit" class="btn btn-primary">Lưu</button>
    </form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampppp\htdocs\GEARS\resources\views/admin/news/create.blade.php ENDPATH**/ ?>