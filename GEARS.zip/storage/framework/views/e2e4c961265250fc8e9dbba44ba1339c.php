<?php $__env->startSection('content'); ?>
    <h1>Chỉnh sửa Loại Sản phẩm #<?php echo e($productType->id); ?></h1>

    <form action="<?php echo e(route('product-types.update', $productType->id)); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>

        <!-- Tên loại sản phẩm cho tiếng Việt -->
        <div class="form-group">
            <label for="name_vi">Tên loại sản phẩm (Tiếng Việt)</label>
            <input type="text" name="name_vi" class="form-control" value="<?php echo e(old('name_vi', $translation_vi->name ?? '')); ?>" required>
        </div>

        <!-- Tên loại sản phẩm cho tiếng Anh -->
        <div class="form-group">
            <label for="name_en">Tên loại sản phẩm (Tiếng Anh)</label>
            <input type="text" name="name_en" class="form-control" value="<?php echo e(old('name_en', $translation_en->name ?? '')); ?>" required>
        </div>

        <!-- Mô tả sản phẩm cho tiếng Việt -->
        <div class="form-group">
            <label for="description_vi">Mô tả sản phẩm (Tiếng Việt)</label>
            <textarea name="description_vi" class="form-control"><?php echo e(old('description_vi', $translation_vi->description ?? '')); ?></textarea>
        </div>

        <!-- Mô tả sản phẩm cho tiếng Anh -->
        <div class="form-group">
            <label for="description_en">Mô tả sản phẩm (Tiếng Anh)</label>
            <textarea name="description_en" class="form-control"><?php echo e(old('description_en', $translation_en->description ?? '')); ?></textarea>
        </div>

        <button type="submit" class="btn btn-primary">Cập nhật</button>
    </form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampppp\htdocs\GEARS\resources\views/admin/product-types/edit.blade.php ENDPATH**/ ?>